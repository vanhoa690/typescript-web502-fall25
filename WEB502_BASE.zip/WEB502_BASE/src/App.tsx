import { Toaster } from 'react-hot-toast'

function App() {

  return (
    <>
      <Toaster/>
    </>
  )
}

export default App
